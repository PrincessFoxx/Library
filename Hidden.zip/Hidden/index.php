<?php
  namespace Foxx\Unit3;

  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
  session_start();

  $game = new Game();

  // if is post
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $game->processPost();
  } else {
    $game->processGet();
  }

  final class Game {
    private const ROWS = 4;
    private const COLS = 5;
    private const HIDDEN1 = "Computer";
    private const HIDDEN2 = "Science";

    private $board = array();

    public function __construct() {

    }

    public function processGet() {
      $this->styleCode();

      echo "<div class='container'>";
        $game = $this->makeBoard();
        echo $this->printBoard(
          [
            $this->random2DLocation(self::ROWS, self::COLS),
            $this->random2DLocation(self::ROWS, self::COLS)
          ]
        );

        echo $this->makeInput();
      echo "</div>";
    }

    public function processPost() {
      $this->styleCode();

      echo "<div class='container'>";

      // check if the submitted location is correct
      $posableLocation = $_POST['guess'];
      
      // if it formatted as "x,y" and is within the board bounds
      if (preg_match('/^\d,\d$/', $posableLocation) && $this->isWithinBounds($posableLocation)) {
        $location = explode(',', $posableLocation);
        $x = $location[0];
        $y = $location[1];

        // if the location is correct
        if ($this->board[$x][$y] == self::HIDDEN1 || $this->board[$x][$y] == self::HIDDEN2) {
          $this->styleCode();
        }
      }


      echo "</div>";
    }

    /**
     * Is within bounds
     * 
     * checks if the given location is within the board bounds
     *
     * @param string $location
     * @return boolean true if within bounds, false otherwise
     */
    private function isWithinBounds(string $location) {
      $location = explode(',', $location);
      $x = $location[0];
      $y = $location[1];

      return $x >= 0 && $x < self::ROWS && $y >= 0 && $y < self::COLS;
    }

    /**
     * style code
     * 
     * Styles the code to make it look nice
     * 
     * @return void
     */
    private function styleCode() {
      echo "<meta charset='utf-8'>";
      echo "<meta name='viewport' content='width=device-width, initial-scale=1'>";
      echo "<meta name=languages' content='en'>";
      echo "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">";
      echo "<link rel='stylesheet' href='style.css'>";
    }

    /**
     * random 2D location
     * 
     * Generates a random 2D location within the given bounds
     *
     * @param integer $rows The number of rows
     * @param integer $cols The number of columns
     * @return array The random 2D location
     */
    private function random2DLocation(int $rows, int $cols): array {
      // get random row and column
      $row = rand(0, $rows - 1);
      $col = rand(0, $cols - 1);
      return [$row, $col];
    }

    /**
     * Create the board and place the hidden words
     * 
     * @return array the board
     */
    private function makeBoard(): array {
      $location1 = $this->random2DLocation(self::ROWS, self::COLS);
      $location2 = $this->random2DLocation(self::ROWS, self::COLS);
      while ($location1 === $location2) {
        $location2 = $this->random2DLocation(self::ROWS, self::COLS);
      }

      $board[$location1[0]][$location1[1]] = self::HIDDEN1;
      $board[$location2[0]][$location2[1]] = self::HIDDEN2;

      // fill in the rest of the board with "X"
      for ($i = 0; $i < self::ROWS; $i++) {
        for ($j = 0; $j < self::COLS; $j++) {
          if (!isset($board[$i][$j])) {
            $board[$i][$j] = "Empty";
          }
        }
      }

      $this->board = $board;
      return $this->board;
    }

    /**
     * Print the board
     * 
     * Prints the board to the screen with the given locations revealed
     * 
     * @param array $revealed The locations to reveal
     * 
     * @return string The HTML code for the board
     */
    private function printBoard(?array $revealed = null): string {
      $board = $this->board;

      $html = "<table class='mb-2 mt-5'>";
      for ($i = 0; $i < self::ROWS; $i++) {
        $html .= "<tr>";
        for ($j = 0; $j < self::COLS; $j++) {
          $html .= "<td>";
          if ($revealed !== null) {
            foreach ($revealed as $location) {
              if ($location[0] === $i && $location[1] === $j) {
                $html .= $board[$i][$j];
              }
            }
          } else {
            $html .= "";
          }
          $html .= "</td>";
        }
        $html .= "</tr>";
      }
      $html .= "</table>";

      return $html;
    }

    /**
     * Make the input fields
     * 
     * @return string The input fields
     */
    private function makeInput(): string {
      $html = "<form action='index.php' method='post' class='mb-1'>";
      $html .= "<input type='text' name='guess' placeholder='Guess'>";
      $html .= "<input type='submit' value='Submit'>";
      $html .= "</form>";
      return $html;
    }   

  }